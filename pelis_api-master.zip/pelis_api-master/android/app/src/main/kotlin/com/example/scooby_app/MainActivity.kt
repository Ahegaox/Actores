package com.example.scooby_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
